#include "PrintFile.h"


int main(int argc , char* argv[])
{
    int numberOfBlocks = std::stoi(argv[1]);
    RunScript(numberOfBlocks);
    return 0;
}