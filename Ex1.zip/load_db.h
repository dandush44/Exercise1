#ifndef LOAD_DB_H
#define LOAD_DB_H

#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <cstdlib>
#include <algorithm>

using namespace std;

struct Block {
    string hash;
    string height;
    string total;
    string time;
    string relayed_by;
    string prev_block;
};


extern vector<Block> blocks;
void loadDataBaseToVector();
void ExportToCsv(vector<Block>& blocks);
bool RunScript(int numBlocks);


#endif // LOAD_DB_H