
#include "PrintFile.h"


int main(int argc ,char* argv[])
{
    string arg = argv[1];
    transform(arg.begin(), arg.end(), arg.begin(), ::tolower);
    loadDataBaseToVector();
    if(arg == "hash")
        printBlockByHash(blocks , argv[2]);
    else if(arg == "height")
        printBlockByHeight(blocks , argv[2]);
    else
        cout << "Invalid option. Try again." << endl;
    loadDataBaseToVector();
    if (blocks.empty()) {
        cout << "No blocks found in the database." << endl;
        return 1;
    }
    return 0;
}