

#include "PrintFile.h"


int main(int argc , char* argv[])
{
    loadDataBaseToVector();
    if (blocks.empty()) {
        cout << "No blocks found in the database." << endl;
        return 1;
    }
while (true) {
    cout << endl;
    cout << "Select an option:" << endl;
    cout << "1. Print the block database" << endl;
    cout << "2. Print block by hash" << endl;
    cout << "3. Print block by height" << endl;
    cout << "4. Export to CSV file" << endl;
    cout << "5. Reload the block database" << endl;
    cout << "> ";

    int choice;
    cin >> choice;

    if (choice == 1) {
        printAllBlocks(blocks);
    } else if (choice == 2) {
        string hash_to_find;
        cout << "Enter the hash of the block you want to find: ";
        cin >> hash_to_find;
        printBlockByHash(blocks , hash_to_find );
    } else if (choice == 3) {
        string height_to_find;
        cout << "Enter the height of the block you want to find: ";
        cin >> height_to_find;
        printBlockByHeight(blocks , height_to_find);
    } else if (choice == 4) {
        ExportToCsv(blocks);
    } else if (choice == 5) {
        int numberOfBlocks;
        cout << "Enter the number of blocks to load: ";
        cin >> numberOfBlocks;
        if(RunScript(numberOfBlocks))
           loadDataBaseToVector();
    } else {
        cout << "Invalid option. Try again." << endl;
    }
}
return 0;
}