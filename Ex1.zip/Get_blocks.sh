#!/bin/bash

X=$1
if [ -z "$X" ]; then
    echo "Usage: $0 <number_of_blocks>"
    exit 1
fi
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
OUTPUT_DIR="$SCRIPT_DIR/TextFiles"
NUM_BLOCKS=$1
mkdir -p "$OUTPUT_DIR"
OUTPUT_FILE="$OUTPUT_DIR/Required_block.txt"
>"$OUTPUT_FILE" 

LATEST_HASH=$(curl -s https://api.blockcypher.com/v1/btc/main | grep '"hash":' | head -n 1 | sed 's/.*"hash": "\(.*\)",*/\1/')

for ((i=1; i <= NUM_BLOCKS; i++))
do
  BLOCK_JSON=$(curl -s "https://api.blockcypher.com/v1/btc/main/blocks/$LATEST_HASH")

  hash=$(echo "$BLOCK_JSON" | grep '"hash":' | sed 's/.*"hash": "\(.*\)",*/\1/')
  height=$(echo "$BLOCK_JSON" | grep '"height"' | sed 's/.*"height": \([0-9]*\),*/\1/')
  total=$(echo "$BLOCK_JSON" | grep '"total"' | sed 's/.*"total": \([0-9]*\),*/\1/')
  time=$(echo "$BLOCK_JSON" | grep '"time"' | sed 's/.*"time": "\(.*\)Z".*/\1/' | sed 's/T/ /')
  relayed_by=$(echo "$BLOCK_JSON" | grep '"relayed_by"' | sed 's/.*"relayed_by": "\(.*\)".*/\1/') 
  prev_block=$(echo "$BLOCK_JSON" | grep '"prev_block"' | sed 's/.*"prev_block": "\(.*\)".*/\1/') 
  {
  echo "========== Block $i =========="
  echo "Hash: $hash"
  echo "Height: $height"
  echo "Total: $total"
  echo "Time: $time"
  echo "Relayed By: $relayed_by"
  echo "Previous Block: $prev_block"
   } >> "$OUTPUT_FILE"
   LATEST_HASH="$prev_block"
done
