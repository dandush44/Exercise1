
#include "load_db.h"


vector<Block> blocks;
string line;
Block block;

void loadDataBaseToVector(){
    ifstream inputFile("TextFiles/Required_block.txt");
    if (!inputFile.is_open()) {
        cerr << " Failed to open Required_block.txt" << endl;
        return;
    }

    while (getline(inputFile, line)) {
        if (line.find("Hash:") == 0)
            block.hash = line.substr(6);
        else if (line.find("Height:") == 0)
            block.height = line.substr(8);
        else if (line.find("Total:") == 0)
            block.total = line.substr(7);
        else if (line.find("Time:") == 0)
            block.time = line.substr(6);
        else if (line.find("Relayed By:") == 0)
            block.relayed_by = line.substr(12);
        else if (line.find("Previous Block:") == 0) {
            block.prev_block = line.substr(17);
            blocks.push_back(block);
            block = Block(); 
        }
    }
    inputFile.close();

}
void ExportToCsv(vector<Block>& blocks)  {
    
    ofstream csvFile("blocks.csv");
    if (!csvFile.is_open()) {
        cerr << " Failed to create blocks.csv" << endl;
        return;
    }

    csvFile << "hash,height,total,time,relayed_by,prev_block\n";

    for (const Block& b : blocks) {
        csvFile << b.hash << "," << b.height << "," << b.total << ","
                << b.time << "," << b.relayed_by << "," << b.prev_block << "\n";
    }

    csvFile.close();
    cout << " Data exported successfully to blocks.csv!" << endl;
}
bool RunScript(int numBlocks){
    

    if (numBlocks <= 0) {
        cerr << "Invalid number. Must be greater than 0." << endl;
        return false;
    }

    blocks.clear();
    string command = "./Get_blocks.sh " + to_string(numBlocks);

    cout << "Executing: " << command << endl;

    
    int result = system(command.c_str());

    if (result != 0) {
        cerr << "Script execution failed with code " << result << endl;
        return false;
    }

    cout << "Block data reloaded successfully." << endl;
    return true;
}