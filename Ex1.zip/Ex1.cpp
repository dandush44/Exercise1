
#include "PrintFile.h"


int main()
{

    loadDataBaseToVector();
    if (blocks.empty()) {
        cout << "No blocks found in the database." << endl;
        return 1;
    }
    printAllBlocks(blocks);
    return 0;
}