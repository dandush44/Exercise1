#include "PrintFile.h"

void printSpecificBlock(const Block& block){
    cout << "hash: " << block.hash << endl;
    cout << "height: " << block.height << endl;
    cout << "total: " << block.total << endl;
    cout << "time: " << block.time << endl;
    cout << "relayed_by: " << block.relayed_by << endl;
    cout << "prev_block: " << block.prev_block << endl;
}

void printBlockByHash(const std::vector<Block>& blocks , std::string hash_to_find) {
 bool found = false;


    for (const auto& block : blocks) {
        if (block.hash == hash_to_find) {
            printSpecificBlock(block);
            found = true;
            break;
        }
    }

    if (!found) {
        std::cout << "Block with hash " << hash_to_find << " not found.\n";
    }
}
void printBlockByHeight(const std::vector<Block>& blocks ,std::string height_to_find) {
    
    bool found = false;

    

    for (const auto& block : blocks) {
        if (block.height == height_to_find) {
            printSpecificBlock(block); 
            found = true;
            break;
        }
    }

    if (!found) {
        std::cout << "Block with height " << height_to_find << " not found.\n";
    }
}


void printAllBlocks(const vector<Block>& blocks){
    for (size_t i = 0; i < blocks.size(); ++i) {
        printSpecificBlock(blocks[i]);
        if (i < blocks.size() - 1) {
            cout << "        |\n        V\n" << endl;
        }
    }

}

