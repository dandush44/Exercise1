#ifndef PRINTFILE_H
#define PRINTFILE_H

#include "load_db.h"

void printSpecificBlock(const Block& block);
void printBlockByHash(const std::vector<Block>& blocks , std::string hash_to_find);
void printBlockByHeight(const std::vector<Block>& blocks ,std::string height_to_find);
void printAllBlocks(const vector<Block>& blocks);

#endif // PRINTFILE_H